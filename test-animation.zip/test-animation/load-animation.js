var canvas = document.getElementById("renderCanvas");

var startRenderLoop = function (engine, canvas) {
    engine.runRenderLoop(function () {
        if (sceneToRender && sceneToRender.activeCamera) {
            sceneToRender.render();
        }
    });
}

var engine = null;
var scene = null;
var sceneToRender = null;
var createDefaultEngine = function () { return new BABYLON.Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true, disableWebGL2Support: false }); };
var createScene = async function () {
    // This creates a basic Babylon Scene object (non-mesh)
    var scene = new BABYLON.Scene(engine);
    scene.debugLayer.show({ showExplorer: true, embedMode: true });

    var camera = new BABYLON.ArcRotateCamera("camera", BABYLON.Tools.ToRadians(90), BABYLON.Tools.ToRadians(65), 10, BABYLON.Vector3.Zero(), scene);
    camera.attachControl(canvas, true);



    // This creates a light, aiming 0,1,0 - to the sky (non-mesh)
    var light = new BABYLON.HemisphericLight("light", new BABYLON.Vector3(0, 1, 0), scene);

    const importedRPM = await BABYLON.SceneLoader.ImportMeshAsync("", "./model/", "63354b2d7ca7d77c3a5febc1.glb", scene);
    const avatar1 = importedRPM.meshes[0];
    const avatar1Armature = avatar1.getChildren((node) => node.name === "Armature", false)[0];

    const importedRPM2 = await BABYLON.SceneLoader.ImportMeshAsync("", "./model/", "621dfdd170f4fcd078c26671.glb", scene);
    const avatar2 = importedRPM2.meshes[0];
    avatar2.position.x += 1;

    const importedAnimations = await BABYLON.SceneLoader.ImportAnimationsAsync("./animation/", "animations.glb", scene, true, BABYLON.SceneLoaderAnimationGroupLoadingMode.Clean, null);

    for (const ag of scene.animationGroups) {
        for (const ta of ag.targetedAnimations) {
            if (!ta.target) {
                ta.target = avatar1Armature;
            }
        }
    }

    const ags = scene.animationGroups.slice(0);
    for (const ag of ags) {
        ag.clone(ag.name + "2", (oldTarget) => {
            return avatar2.getChildren((node) => node.name === oldTarget.name, false)[0];
        }, true);
    }

    const anim = scene.getAnimationGroupByName("BreathingIdle");
    anim.start(true, 1, anim.from, anim.to, false);

    const anim2 = scene.getAnimationGroupByName("Running2");
    anim2.start(true, 1, anim2.from, anim2.to, false);

    return scene;
};
window.initFunction = async function () {



    var asyncEngineCreation = async function () {
        try {
            return createDefaultEngine();
        } catch (e) {
            console.log("the available createEngine function failed. Creating the default engine instead");
            return createDefaultEngine();
        }
    }

    // window.engine = await asyncEngineCreation();
    engine = await asyncEngineCreation();
    window.engine = engine;
    if (!engine) throw 'engine should not be null.';
    startRenderLoop(engine, canvas);
    // window.scene = createScene();
    scene = createScene();
    window.scene = scene;
};
initFunction().then(() => {
    scene.then(returnedScene => { sceneToRender = returnedScene; });

});

// Resize
window.addEventListener("resize", function () {
    engine.resize();
});